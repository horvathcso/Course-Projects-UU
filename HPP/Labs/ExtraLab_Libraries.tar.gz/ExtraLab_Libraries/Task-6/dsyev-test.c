/* Declaration for dsyev_() */
void dsyev_(const char *jobz, const char *uplo, const int *n,
	    double *a, const int *lda, double *w, double *work,
	    const int *lwork, int *info);

/* TODO: write your code here! */
