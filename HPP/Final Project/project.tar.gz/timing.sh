#!/bin/bash

echo "Original"
gcc origin_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file v2"
echo 
gcc v2_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file v4"
echo 
gcc v4_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo



echo "\n New file v5"
echo 
gcc v5_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo




echo "\n New file v6"
echo 
gcc v6_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file: final_test"
echo 
gcc final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1

echo "\n New file: v1"
echo 
gcc v1_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo



echo "\n New file: final_test o1"
echo 
gcc -O1 final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file: final_test o2"
echo 
gcc -O2 final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo

echo "\n New file: final_test o3"
echo 
gcc -O3 final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file: final_test ofast"
echo 
gcc -Ofast final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file: final_test ofast march=native"
echo 
gcc -Ofast -march=native final_test.c -o test
echo "4x4 table:"
./test 4 input_4_v1
res1=$(./test 3 input_3_sud_ord_2)
res2=$(./test 3 input_3_sud_ord_3)
res3=$(./test 3 input_3_sud_ord_4)
echo "Sudokus:"
echo "$res1+$res2+$res3" |bc

res4=$(./test 3 input_3_78_6)
res5=$(./test 3 input_3_79_6)
res6=$(./test 3 input_3v1)
res7=$(./test 3 input_3v2)
res8=$(./test 3 input_3v3)
res9=$(./test 3 input_3vv1)
res10=$(./test 3 input_3vv2)
res11=$(./test 3 input_3vv3)
echo "Shuffled 3"
echo "$res4+$res5+$res6+$res7+$res8+$res9+$res10+$res11" |bc
echo "Unsolvable sudoku"
./test 3 sudoku_vv1
echo
echo


echo "\n New file: para"
echo 
gcc -Ofast test_pthread.c -lpthread -o test
echo "Unsolvable sudoku"
./test 3 sudoku_vv1


echo 
echo
echo "para multiple runs"
./test 3 input_3v3
./test 3 input_3v3
./test 3 input_3v3
./test 3 input_3v3
./test 3 input_3v3
./test 3 input_3v3
